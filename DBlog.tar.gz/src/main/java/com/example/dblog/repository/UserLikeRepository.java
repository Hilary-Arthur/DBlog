package com.example.dblog.repository;

import com.example.dblog.entity.UserLike;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserLikeRepository extends JpaRepository<UserLike, Long> {

    boolean existsByPostPidAndUserUid(Long pid, Long uid);

    List<UserLike> findByUserUid(Long uid);

    int countByPostPid(Long pid);

    void deleteByPostPidAndUserUid(Long pid, Long uid);
}
