package com.example.dblog.service;

import com.example.dblog.entity.Post;
import com.example.dblog.entity.User;
import com.example.dblog.entity.UserLike;
import com.example.dblog.repository.PostRepository;
import com.example.dblog.repository.UserLikeRepository;
import com.example.dblog.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class LikeService {

    private final UserLikeRepository userLikeRepo;
    private final PostRepository postRepo;
    private final UserRepository userRepo;

    public LikeService(UserLikeRepository userLikeRepo, PostRepository postRepo, UserRepository userRepo) {
        this.userLikeRepo = userLikeRepo;
        this.postRepo = postRepo;
        this.userRepo = userRepo;
    }

    /** Toggle like: if liked, unlike; if not liked, like. Returns [newLikedState(1/0), count]. */
    @Transactional
    public long[] toggle(Long pid, Long uid) {
        boolean alreadyLiked = userLikeRepo.existsByPostPidAndUserUid(pid, uid);
        if (alreadyLiked) {
            userLikeRepo.deleteByPostPidAndUserUid(pid, uid);
        } else {
            Post post = postRepo.findById(pid).orElse(null);
            User user = userRepo.findById(uid).orElse(null);
            if (post == null || user == null) return new long[]{0, 0};
            userLikeRepo.save(new UserLike(post, user));
        }
        int count = userLikeRepo.countByPostPid(pid);
        // Update denormalized like_count on post
        postRepo.findById(pid).ifPresent(post -> {
            post.setLikeCount(count);
            postRepo.save(post);
        });
        return new long[]{alreadyLiked ? 0 : 1, count};
    }

    /** Get like count (from user_like table, fallback to denormalized column) */
    public int getLikeCount(Long pid) {
        int count = userLikeRepo.countByPostPid(pid);
        if (count > 0) return count;
        return postRepo.findById(pid).map(p -> p.getLikeCount() != null ? p.getLikeCount() : 0).orElse(0);
    }

    /** Check if a user has liked a post */
    public boolean isLikedBy(Long pid, Long uid) {
        if (uid == null) return false;
        return userLikeRepo.existsByPostPidAndUserUid(pid, uid);
    }

    /** Get the set of post IDs that the user has liked, from a given list */
    public Set<Long> getLikedPids(Long uid, List<Long> pids) {
        if (uid == null || pids.isEmpty()) return Set.of();
        Set<Long> likedPids = userLikeRepo.findByUserUid(uid).stream()
                .map(ul -> ul.getPost().getPid())
                .collect(Collectors.toSet());
        likedPids.retainAll(new HashSet<>(pids));
        return likedPids;
    }
}
